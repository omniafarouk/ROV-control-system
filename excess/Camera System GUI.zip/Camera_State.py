from enum import Enum


class CameraState(Enum):
    MAXIMIZED = "maximized"
    NORMAL = "normal"

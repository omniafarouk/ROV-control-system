from abc import ABC, abstractmethod


class stereoVisionProcess(ABC):

    @abstractmethod
    def create(self):
        pass
